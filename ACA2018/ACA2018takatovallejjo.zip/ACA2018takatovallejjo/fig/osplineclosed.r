# date time=2018/10/1 07:38:20

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='osplineclosed.tex'
FnameR='osplineclosed.r'
Fnameout='osplineclosed.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-3.5,3.5), c(-2.5,2.5))
A=c(-3,0);Assignadd('A',A)
B=c(0,2);Assignadd('B',B)
C=c(3,0);Assignadd('C',C)
D=c(0,-2);Assignadd('D',D)
gp1=Paramplot('c(3*cos(t),2*sin(t))','t=c(0,2*pi)')
bzo1=Bezier(list(c(3,0),c(0,2),c(-3,0),c(0,-2),c(3,0)),list(c(c(3,1.12644),c(1.68967,2)),c(c(-1.68967,2),c(-3,1.12644)),c(c(-3,-1.12644),c(-1.68967,-2)),c(c(1.68967,-2),c(3,-1.12644))))
ptc1=Pointdata(list(c(3,1.126444),c(1.689666,2)))
ptc2=Pointdata(list(c(-1.689666,2),c(-3,1.126444)))
ptc3=Pointdata(list(c(-3,-1.126444),c(-1.689666,-2)))
ptc4=Pointdata(list(c(1.689666,-2),c(3,-1.126444)))
pt1=Pointdata(list(C,B,A,D))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/osplineclosed.tex','1cm','Cdy=crspine.cdy')
Dashline(gp1)
Drwline(bzo1)
Setpt(3)
Setpen(0.38)
Drwpt(list(ptc1))
Setpen(1)
Setpt(1)
Setpt(3)
Setpen(0.38)
Drwpt(list(ptc2))
Setpen(1)
Setpt(1)
Setpt(3)
Setpen(0.38)
Drwpt(list(ptc3))
Setpen(1)
Setpt(1)
Setpt(3)
Setpen(0.38)
Drwpt(list(ptc4))
Setpen(1)
Setpt(1)
Setpt(3)
Setpen(0.38)
Drwpt(list(pt1))
Setpen(1)
Setpt(1)
Letter(c(3,0),"ne","A")
Letter(c(0,2),"ne","B")
Letter(c(-3,0),"nw","C")
Letter(c(0,-2),"se","D")
Closefile('1')

}

quit()
