# date time=2018/10/4 18:58:33

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='derivimp.tex'
FnameR='derivimp.r'
Fnameout='derivimp.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-1.08,2.4), c(-0.67,3.13))
imp1=Implicitplot('8*x^2-4*sqrt(2)*x*y+y^2-3*x-6*sqrt(2)*y+2=0','x=c(-2,2)','y=c(-2,2.5)')
lntn0=Lineplot(c(c(2,1.53299),c(1.9975,1.53002)))
lntn1=Lineplot(c(c(1.7408,1.22949),c(1.7193,1.20541)))
lntn2=Lineplot(c(c(1.48161,0.95036),c(1.46505,0.93348)))
lntn3=Lineplot(c(c(1.22241,0.70051),c(1.21579,0.69448)))
lntn4=Lineplot(c(c(0.96322,0.48601),c(0.93479,0.46496)))
lntn5=Lineplot(c(c(0.70402,0.31767),c(0.68038,0.30521)))
lntn6=Lineplot(c(c(0.44482,0.20948),c(0.41815,0.20218)))
lntn7=Lineplot(c(c(0.18563,0.18527),c(0.15904,0.18855)))
lntn8=Lineplot(c(c(-0.07357,0.29205),c(-0.09292,0.30696)))
lntn9=Lineplot(c(c(-0.33276,0.65508),c(-0.34268,0.67904)))
lntn10=Lineplot(c(c(-0.59196,2.38492),c(-0.59302,2.42293)))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/derivimp.tex','1cm','Cdy=derivative.cdy')
Drwline(imp1,1)
Letter(c(2,1.53),"cn","P")
Letter(c(-0.59,2.5),"cn","Q")
Drwline(lntn0,0.2)
Drwline(lntn1,0.2)
Drwline(lntn2,0.2)
Drwline(lntn3,0.2)
Drwline(lntn4,0.2)
Drwline(lntn5,0.2)
Drwline(lntn6,0.2)
Drwline(lntn7,0.2)
Drwline(lntn8,0.2)
Drwline(lntn9,0.2)
Drwline(lntn10,0.2)
Closefile('1')

}

quit()
