# date time=2018/10/12 16:12:50

setwd('/acapaper2018.git/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='crsplineall.tex'
FnameR='crsplineall.r'
Fnameout='crsplineall.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-1,5), c(-1,5))
A=c(-1.56357,0.51267);Assignadd('A',A)
B=c(1.003864,1.217452);Assignadd('B',B)
C=c(3.609639,3.267898);Assignadd('C',C)
D=c(5.425138,4.912527);Assignadd('D',D)
mdbw2=c(3.91721,2.24268);Assignadd('mdbw2',mdbw2)
mdbw1=c(2.30675,0.95687);Assignadd('mdbw1',mdbw1)
bzCR1=Bezier(list(c(-1.56357,0.51267),c(1.00386,1.21745),c(3.60964,3.2679),c(5.42514,4.91253)),list(c(c(-0.58776,0.55801),c(0.14166,0.75825)),c(c(1.86607,1.67666),c(2.87276,2.65205)),c(c(4.34652,3.88374),c(4.73969,4.23991))))
sg1=Listplot(c(c(1.00386,1.21745),c(3.60964,1.21745),c(3.60964,3.2679),c(1.00386,1.21745)))
bw1=Bowdata(B,c(3.60964,1.21745))
bw2=Bowdata(c(3.60964,1.21745),C,1.5)
sght1=Listplot(c(c(1.00386,0.05),c(1.00386,-0.05)))
sght3=Listplot(c(c(3.60964,0.05),c(3.60964,-0.05)))
sgvt1=Listplot(c(c(0.05,1.21745),c(-0.05,1.21745)))
sgvt3=Listplot(c(c(0.05,3.2679),c(-0.05,3.2679)))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/acapaper2018.git/fig/crsplineall.tex','1cm','Cdy=crspine.cdy')
Drwline(bzCR1)
Drwline(sg1)
Letter(c(2.31,0.96),"c","$\\Delta x$")
Dottedline(bw1)
Letter(c(3.92,2.24),"c","$\\Delta y$")
Dottedline(bw2)
Letter(c(1,1.22),"cn","P")
Drwline(sght1)
Letter(c(1,0),"cs1","$x$")
Drwline(sght3)
Letter(c(3.61,0),"cs1","$\\xi$")
Drwline(sgvt1)
Letter(c(0,1.22),"w1","$f(x)$")
Drwline(sgvt3)
Letter(c(0,3.27),"w1","$f(\\xi)$")
Closefile('1')

}

quit()
