# date time=2018/10/7 07:37:38

setwd('/acapaper2018.git/fig/mobius')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='p004.tex'
FnameR='p004.r'
Fnameout='p004.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-5.19,4.75), c(-2.08,3.32))
TH=c(-1.34991,-2.5);Assignadd('TH',TH)
Oz=c(9.948496,0);Assignadd('Oz',Oz)
Xz=c(8.579086,0);Assignadd('Xz',Xz)
Yz=c(12.617716,0);Assignadd('Yz',Yz)
Zz=c(9.948496,3);Assignadd('Zz',Zz)
FI=c(-4.32101,-3);Assignadd('FI',FI)
Sl=c(0,-3.57786);Assignadd('Sl',Sl)
Sr=c(6.28319,-3.57786);Assignadd('Sr',Sr)
S=c(2.59733,-3.57786);Assignadd('S',S)
O=c(0,0);Assignadd('O',O)
X=c(-1.36941,-0.78032);Assignadd('X',X)
Y=c(2.66922,-0.40034);Assignadd('Y',Y)
Z=c(0,2.86894);Assignadd('Z',Z)
Zfix=1;Assignadd('Zfix',Zfix)
Z3d=c(0,0,3);Assignadd('Z3d',Z3d)
Yfix=1;Assignadd('Yfix',Yfix)
Y3d=c(0,3,0);Assignadd('Y3d',Y3d)
Xfix=1;Assignadd('Xfix',Xfix)
X3d=c(3,0,0);Assignadd('X3d',X3d)
Ofix=1;Assignadd('Ofix',Ofix)
O3d=c(0,0,0);Assignadd('O3d',O3d)
sgth=Listplot(c(c(-5,-2.5),c(4,-2.5)))
sgph=Listplot(c(c(-5,-3),c(4,-3)))
Setangle(73.0018,27.1596)
sgSlSr=Listplot(c(c(0,-3.57786),c(6.28319,-3.57786)))
ReadOutData("p004.txt")
sfbd2d1=Projpara(sfbd3d1)
wire2d1u1=Projpara(wire3d1u1)
wire2d1u2=Projpara(wire3d1u2)
wire2d1u3=Projpara(wire3d1u3)
wire2d1u4=Projpara(wire3d1u4)
wire2d1u5=Projpara(wire3d1u5)
wire2d1v1=Projpara(wire3d1v1)
sfbdh2d1=Projpara(sfbdh3d1)
wireh2d1u1=Projpara(wireh3d1u1)
wireh2d1u2=Projpara(wireh3d1u2)
wireh2d1u3=Projpara(wireh3d1u3)
wireh2d1u4=Projpara(wireh3d1u4)
wireh2d1u5=Projpara(wireh3d1u5)
wireh2d1v1=Projpara(wireh3d1v1)
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/acapaper2018.git/fig/mobius/p004.tex','1cm','Cdy=animemobius.cdy')
Drwline(sfbd2d1)
Drwline(wire2d1u1)
Drwline(wire2d1u2)
Drwline(wire2d1u3)
Drwline(wire2d1u4)
Drwline(wire2d1u5)
Drwline(wire2d1v1)
Closefile('0')

}

quit()
