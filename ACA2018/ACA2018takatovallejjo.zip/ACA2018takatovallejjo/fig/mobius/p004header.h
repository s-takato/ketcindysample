const double XMIN=-5.194654,XMAX=4.753841;/**/
const double THETA=1.274122,PHI=0.474024;/**/
  //THETA:73.00, PHI:27.16;/**/
const int Mdv=50,Ndv=50;/**/
#define DsizeLL 5000/**/
#define DsizeL 1500/**/
#define DsizeM 500/**/
#define DsizeS 200/**/
const double Eps=0.00001, Eps1=0.01, Eps2=0.1;/**/
const char Dirname[]="/acapaper2018.git/fig/mobius/";/**/
double Urng[2],Vrng[2];/**/
int DrawE,DrawW,DrawS,DrawN;/**/
void rangeUV(short ch){/**/
  switch(ch){/**/
    case 1 : Urng[0]=-0.4;Urng[1]=0.4;Vrng[0]=0;Vrng[1]=0.79;break;/**/
  }/**/
}/**/
void boundary(short ch){/**/
  switch(ch){/**/
    case 1 : DrawE=1;DrawW=1;DrawS=1;DrawN=1;break;/**/
  }/**/
}/**/
void surffun(short ch,double u, double v, double p[3]){/**/
  switch(ch){/**/
    case 1 : p[0]=2.0*cos(v)*(2.0+u*cos(v/2.0));p[1]=2.0*sin(v)*(2.0+u*cos(v/2.0));p[2]=2.0*u*sin(v/2.0);break;/**/
  }/**/
}/**/
