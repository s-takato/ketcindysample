#!/bin/sh
cd "/acapaper2018.git/fig/mobius"
/Library/Frameworks/R.framework/Versions/Current/Resources/bin/R  --vanilla --slave < animemobius.r 2> errormessageR.txt
exit 0
