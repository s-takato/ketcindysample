#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "p001header.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/ketcommonhead.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/ketcommon.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/surflibhead.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/surflib.h"
double cutfun(short chfd, short chcut, double u, double v){
  double p[3],val;
  surffun(chfd,u,v,p);
  switch(chcut){
    case 1: val=1;break;
  }
  return val;
}
int main(void){
  double data[DsizeL][3],sfbd[DsizeL][3],out[DsizeL][3];
  int i, j, nall;
  char dirfname[256] = {'\0'};
/**/
  printf("%s\n","p001");/**/
  char fnameall[]="p001.txt";/**/
  rangeUV(1);/**/
  boundary(1);/**/
  sfbdparadata(1,sfbd);/**/
  sprintf(dirfname,"%s%s",Dirname,fnameall);/**/
  output3h("w","sfbd3d1","sfbdh3d1",dirfname,sfbd);/**/
  double wireu[]={5,-0.266667,-0.133333,0,0.133333,0.266667};/**/
  double wirev[]={0};/**/
  rangeUV(1);/**/
  boundary(1);/**/
  readoutdata3(fnameall,"sfbd3d1",sfbd);/**/
  wireparadata(1,sfbd,wireu,wirev,fnameall,"");/**/
  outputend(dirfname);/**/
  return 0;
}
