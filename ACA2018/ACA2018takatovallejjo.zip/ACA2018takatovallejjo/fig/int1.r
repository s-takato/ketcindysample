# date time=2018/10/4 13:46:41

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='int1.tex'
FnameR='int1.r'
Fnameout='int1.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-0.24,6.48), c(-0.2,3.45))
A=c(0.97979,1.38061);Assignadd('A',A)
B=c(1.95957,2.33812);Assignadd('B',B)
C=c(4.52037,2.91709);Assignadd('C',C)
D=c(5.76737,2.40493);Assignadd('D',D)
bz1=Bezier(list(c(0.97979,1.38061),c(5.76737,2.40493)),list(c(c(1.95957,2.33812),c(4.52037,2.91709))),"Num=50")
sg1=Listplot(c(c(0.97979,1.38061),c(0.97979,0)))
sg2=Listplot(c(c(5.76737,2.40493),c(5.76737,0)))
sg3=Listplot(c(c(0.97979,0),c(5.76737,0)))
en1=Enclosing2(list(sg1,sg3,Invert(sg2),Invert(bz1)),c(0.97979,1.38061),1)
ha1=Hatchdata(c("i"),list(en1))
pt1=Pointdata(list(A,B,C,D))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/int1.tex','1cm','Cdy=derivint.cdy')
Drwline(bz1,1.5)
Drwline(sg1)
Drwline(sg2)
Drwline(ha1)
Setpt(3)
Setpen(0.38)
Drwpt(list(pt1))
Setpen(1)
Setpt(1)
Letter(c(0.98,1.38),"nw","$\\mathrm{P}_j$")
Letter(c(1.96,2.34),"cn","$\\mathrm{P}_{j+1}$")
Letter(c(4.52,2.92),"cn","$\\mathrm{P}_{j+2}$")
Letter(c(5.77,2.4),"ne","$\\mathrm{P}_{j+3}$")
Letter(c(3.24,2.63),"c","$C$")
Closefile('1')

}

quit()
