# date time=2018/9/30 15:58:10

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='crospline1.tex'
FnameR='crospline1.r'
Fnameout='crospline1.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-3.5,3.5), c(-2.5,2.5))
A=c(-3.279109,-1.831861);Assignadd('A',A)
B=c(-1.81922,0.021075);Assignadd('B',B)
C=c(1.289424,1.15938);Assignadd('C',C)
D=c(3.144061,0.410719);Assignadd('D',D)
E=c(1.755636,-1.0832);Assignadd('E',E)
pt1=Pointdata(list(c(-3.279109,-1.831861),c(-1.81922,0.021075),c(1.289424,1.15938),c(3.144061,0.410719),c(1.755636,-1.0832)))
sg1=Listplot(c(c(-3.27911,-1.83186),c(1.28942,1.15938)))
sg2=Listplot(c(c(-1.81922,0.02107),c(3.14406,0.41072)))
sg3=Listplot(c(c(1.28942,1.15938),c(1.75564,-1.0832)))
bzCR1=Bezier(list(c(-3.27911,-1.83186),c(-1.81922,0.02107),c(1.28942,1.15938),c(3.14406,0.41072),c(1.75564,-1.0832)),list(c(c(-2.97258,-0.97492),c(-2.58064,-0.47747)),c(c(-1.0578,0.51961),c(0.46221,1.09444)),c(c(2.11664,1.22432),c(3.06636,0.78448)),c(c(3.22176,0.03696),c(2.13408,-1.13337))))
pt2=Pointdata(list(c(-1.0578,0.51961),c(0.46221,1.09444)))
pt3=Pointdata(list(c(2.11664,1.22432),c(3.06636,0.78448)))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/crospline1.tex','1cm','Cdy=ospine.cdy')
Setpt(3)
Setpen(0.38)
Drwpt(list(pt1))
Setpen(1)
Setpt(1)
Dashline(sg1)
Dashline(sg2)
Dashline(sg3)
Letter(c(-3.28,-1.83),"nw","$\\mathrm{P}_{j-1}$")
Letter(c(-1.82,0.02),"nw","$\\mathrm{P}_{j}$")
Letter(c(1.29,1.16),"cn","$\\mathrm{P}_{j+1}$")
Letter(c(3.14,0.41),"e","$\\mathrm{P}_{j+2}$")
Letter(c(1.76,-1.08),"cs","$\\mathrm{P}_{j+3}$")
Drwline(bzCR1)
Setpt(3)
Setpen(0.38)
Drwpt(list(pt2))
Setpen(1)
Setpt(1)
Setpt(3)
Setpen(0.38)
Drwpt(list(pt3))
Setpen(1)
Setpt(1)
Letter(c(-1.06,0.52),"cn","$\\mathrm{Q}_{j}$")
Letter(c(0.46,1.09),"cn","$\\mathrm{R}_{j}$")
Closefile('0')

}

quit()
