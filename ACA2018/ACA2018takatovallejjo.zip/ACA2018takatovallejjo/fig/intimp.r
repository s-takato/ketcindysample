# date time=2018/10/4 16:52:04

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='intimp.tex'
FnameR='intimp.r'
Fnameout='intimp.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-1,2.5), c(-0.5,3))
imp1=Implicitplot('8*x^2-4*sqrt(2)*x*y+y^2-3*x-6*sqrt(2)*y+2=0','x=c(-2,2)','y=c(-2,2.5)')
sg1=Listplot(c(c(-0.59196,2.5),c(-0.59196,0),c(2,0),c(2,1.53299)))
en1=Enclosing2(list(imp1,sg1),c(2,1.53299),1)
ha1=Hatchdata(c("i"),list(en1))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/intimp.tex','1cm','Cdy=integrate.cdy')
Drwline(imp1)
Drwline(sg1)
Drwline(ha1)
Letter(c(2,1.53),"cn","P")
Letter(c(-0.59,2.5),"cn","Q")
Closefile('1')

}

quit()
