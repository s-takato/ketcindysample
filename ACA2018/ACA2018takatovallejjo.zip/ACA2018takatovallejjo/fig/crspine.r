# date time=2018/9/28 11:38:28

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='crspine.tex'
FnameR='crspine.r'
Fnameout='crspine.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-1,5), c(-1,5))
A=c(-1.563571,0.512667);Assignadd('A',A)
B=c(1.315287,1.003382);Assignadd('B',B)
C=c(3.670716,2.148382);Assignadd('C',C)
D=c(5.273717,4.209383);Assignadd('D',D)
bzCR1=Bezier(list(c(-1.56357,0.51267),c(1.31529,1.00338),c(3.67072,2.14838),c(5.27372,4.20938)),list(c(c(-0.65014,0.54445),c(0.44291,0.73076)),c(c(2.18767,1.276),c(3.01098,1.61405)),c(c(4.33045,2.68272),c(4.91822,3.43842))))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/crspine.tex','1cm','Cdy=crspine.cdy')
Drwline(bzCR1)
Closefile('1')

}

quit()
