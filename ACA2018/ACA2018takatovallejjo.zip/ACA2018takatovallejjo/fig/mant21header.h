const double XMIN=-2.961295,XMAX=3.238916;/**/
const double THETA=1.221730,PHI=0.820416;/**/
  //THETA:70.00, PHI:47.01;/**/
const int Mdv=50,Ndv=50;/**/
#define DsizeLL 5000/**/
#define DsizeL 1500/**/
#define DsizeM 500/**/
#define DsizeS 200/**/
const double Eps=0.00001, Eps1=0.01, Eps2=0.1;/**/
const char Dirname[]="/acapaper2018.git/fig/";/**/
double Urng[2],Vrng[2];/**/
int DrawE,DrawW,DrawS,DrawN;/**/
void rangeUV(short ch){/**/
  switch(ch){/**/
    case 1 : Urng[0]=-1.5;Urng[1]=1.5;Vrng[0]=-1.5;Vrng[1]=1.5;break;/**/
  }/**/
}/**/
void boundary(short ch){/**/
  switch(ch){/**/
    case 1 : DrawE=1;DrawW=1;DrawS=1;DrawN=1;break;/**/
  }/**/
}/**/
void surffun(short ch,double u, double v, double p[3]){/**/
  switch(ch){/**/
    case 1 : p[0]=u;p[1]=v;p[2]=3.0*(1.0-(2.0*pow(u,2.0)+pow(v,2.0))*exp(-pow(u,2.0)-pow(v,2.0)));break;/**/
  }/**/
}/**/
