#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "paraboloid1header.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/ketcommonhead.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/ketcommon.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/surflibhead.h"
#include "/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlibC/surflib.h"
double cutfun(short chfd, short chcut, double u, double v){
  double p[3],val;
  surffun(chfd,u,v,p);
  switch(chcut){
    case 1: val=1;break;
  }
  return val;
}
int main(void){
  double data[DsizeL][3],sfbd[DsizeL][3],out[DsizeL][3];
  int i, j, nall;
  char dirfname[256] = {'\0'};
/**/
  printf("%s\n","paraboloid");/**/
  char fnameall[]="paraboloid1.txt";/**/
  rangeUV(1);/**/
  boundary(1);/**/
  sfbdparadata(1,sfbd);/**/
  sprintf(dirfname,"%s%s",Dirname,fnameall);/**/
  output3h("w","sfbd3d1","sfbdh3d1",dirfname,sfbd);/**/
  char fname1[]="paraboloidcrvsf1.txt";/**/
  rangeUV(1);/**/
  boundary(1);/**/
  readdataC("paraboloidax3d.dat",data);/**/
  readoutdata3(fnameall,"sfbd3d1",sfbd);/**/
  crvsfparadata(1,data,sfbd, 0, out);/**/
  sprintf(dirfname,"%s%s",Dirname,fnameall);/**/
  output3h("a","crvsf3d1","crvsfh3d1",dirfname,out);/**/
  double wireu[]={5,0.333333,0.666667,1,1.333333,1.666667};/**/
  double wirev[]={6,0,1.047198,2.094395,3.141593,4.18879,5.235988};/**/
  rangeUV(1);/**/
  boundary(1);/**/
  readoutdata3(fnameall,"sfbd3d1",sfbd);/**/
  wireparadata(1,sfbd,wireu,wirev,fnameall,"");/**/
  outputend(dirfname);/**/
  return 0;
}
