# date time=2018/10/6 06:12:34

setwd('/acapaper2018.git/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='mant.tex'
FnameR='mant.r'
Fnameout='mant.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-2.96,3.24), c(-1.54,4.32))
TH=c(-1.5,-2);Assignadd('TH',TH)
FI=c(-3.82484,-2.5);Assignadd('FI',FI)
O=c(0,0);Assignadd('O',O)
Oz=c(6.200211,0);Assignadd('Oz',Oz)
X=c(-2.92572,-0.93292);Assignadd('X',X)
Xz=c(3.274491,0);Assignadd('Xz',Xz)
Y=c(2.72767,-1.00066);Assignadd('Y',Y)
Yz=c(8.927881,0);Assignadd('Yz',Yz)
Z=c(0,3.75877);Assignadd('Z',Z)
Zz=c(6.200211,4);Assignadd('Zz',Zz)
Zfix=1;Assignadd('Zfix',Zfix)
Z3d=c(0,0,4);Assignadd('Z3d',Z3d)
Yfix=1;Assignadd('Yfix',Yfix)
Y3d=c(0,4,0);Assignadd('Y3d',Y3d)
Xfix=1;Assignadd('Xfix',Xfix)
X3d=c(4,0,0);Assignadd('X3d',X3d)
Ofix=1;Assignadd('Ofix',Ofix)
O3d=c(0,0,0);Assignadd('O3d',O3d)
sgth=Listplot(c(c(-5,-2),c(4,-2)))
sgph=Listplot(c(c(-5,-2.5),c(4,-2.5)))
Setangle(70,47.0064)
ax3d=Xyzax3data("x=c(-3,3)","y=c(-3,3)","z=c(-2,4)")
ax2d=Projpara(ax3d)
ReadOutData("mant1.txt")
sfbd2d1=Projpara(sfbd3d1)
crvsf2d1=Projpara(crvsf3d1)
sfbdh2d1=Projpara(sfbdh3d1)
crvsfh2d1=Projpara(crvsfh3d1)
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/acapaper2018.git/fig/mant.tex','1cm','Cdy=mant.cdy')
Letter(c(-2.38,-0.76),"c","$x$")
Letter(c(2.22,-0.82),"c","$y$")
Letter(c(0,3.95),"c","$z$")
Drwline(sfbd2d1)
Drwline(crvsf2d1)
Closefile('0')

}

quit()
