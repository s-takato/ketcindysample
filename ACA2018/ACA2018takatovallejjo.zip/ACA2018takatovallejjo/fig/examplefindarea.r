# date time=2018/10/11 09:25:01

setwd('/acapaper2018.git/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='examplefindarea.tex'
FnameR='examplefindarea.r'
Fnameout='examplefindarea.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-5.02,4.89), c(-4.15,3.51))
A=c(-3.14159,-5.14557);Assignadd('A',A)
B=c(3.14159,-5.14557);Assignadd('B',B)
C=c(0.79329,-5.14557);Assignadd('C',C)
sgAB=Listplot(c(c(-3.14159,-5.14557),c(3.14159,-5.14557)))
gp1=Paramplot('c(3*cos(t),2*sin(t))','t=c(0,2*pi)',"Num=50")
rt1=Rotatedata(gp1,0.79329,c(0,0))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/acapaper2018.git/fig/examplefindarea.tex','1cm','Cdy=examplefindarea.cdy')
Texcom("{")
Setcolor(c(1,0,0))
Drwline(gp1)
Texcom("}")
Drwline(rt1)
Letter(c(0,-3.15),"w1","$\\theta=45.45^\\circ$")
Letter(c(0,-3.15),"e1","$\\frac{S}{\\pi a b}=0.999998$")
Closefile('1')

}

quit()
