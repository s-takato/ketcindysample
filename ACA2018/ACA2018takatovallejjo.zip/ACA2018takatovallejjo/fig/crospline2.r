# date time=2018/9/30 16:06:01

setwd('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
source('/Applications/kettex/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent_rep2e.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='crospline2.tex'
FnameR='crospline2.r'
Fnameout='crospline2.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-3.5,3.5), c(-2.5,2.5))
A=c(-3.279109,-1.831861);Assignadd('A',A)
B=c(-1.81922,0.021075);Assignadd('B',B)
C=c(1.289424,1.15938);Assignadd('C',C)
D=c(3.144061,0.410719);Assignadd('D',D)
E=c(1.755636,-1.0832);Assignadd('E',E)
mdag1=c(0.39999,0.36947);Assignadd('mdag1',mdag1)
pt1=Pointdata(list(c(-3.279109,-1.831861),c(-1.81922,0.021075),c(1.289424,1.15938),c(3.144061,0.410719),c(1.755636,-1.0832)))
sg1=Listplot(c(c(-3.27911,-1.83186),c(1.28942,1.15938)))
sg2=Listplot(c(c(-1.81922,0.02107),c(3.14406,0.41072)))
sg3=Listplot(c(c(1.28942,1.15938),c(1.75564,-1.0832)))
bzo1=Bezier(list(c(-3.27911,-1.83186),c(-1.81922,0.02107),c(1.28942,1.15938),c(3.14406,0.41072),c(1.75564,-1.0832)),list(c(c(-2.80041,-0.62136)),c(c(-0.83803,0.6635),c(0.22346,1.0757)),c(c(2.32964,1.24104),c(3.04635,0.88072)),c(c(3.24177,-0.05929))))
pt2=Pointdata(list(c(-0.83803,0.6635),c(0.22346,1.0757)))
pt3=Pointdata(list(c(2.32964,1.24104),c(3.04635,0.88072)))
ag1=Anglemark(c(3.14406,0.41072),c(-0.26246,0.14329),c(1.28942,1.15938))
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('/Users/takatoosetsuo/Dropbox/2018ketpic/ACA2018/paper/fig/crospline2.tex','1cm','Cdy=ospine.cdy')
Setpt(3)
Setpen(0.38)
Drwpt(list(pt1))
Setpen(1)
Setpt(1)
Dashline(sg1)
Dashline(sg2)
Dashline(sg3)
Letter(c(-3.28,-1.83),"nw","$\\mathrm{P}_{j-1}$")
Letter(c(-1.82,0.02),"nw","$\\mathrm{P}_{j}$")
Letter(c(1.29,1.16),"cn","$\\mathrm{P}_{j+1}$")
Letter(c(3.14,0.41),"e","$\\mathrm{P}_{j+2}$")
Letter(c(1.76,-1.08),"cs","$\\mathrm{P}_{j+3}$")
Drwline(bzo1)
Setpt(3)
Setpen(0.38)
Drwpt(list(pt2))
Setpen(1)
Setpt(1)
Setpt(3)
Setpen(0.38)
Drwpt(list(pt3))
Setpen(1)
Setpt(1)
Letter(c(-0.84,0.66),"cn","$\\mathrm{Q}_{j}$")
Letter(c(0.22,1.08),"cn","$\\mathrm{R}_{j}$")
Letter(c(0.4,0.37),"c","$\\theta$")
Drwline(ag1)
Closefile('0')

}

quit()
