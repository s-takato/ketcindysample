#!/bin/sh
cd "/acapaper2018.git/fig"
rm integratemx1.txt
"/Applications/Maxima.app/Contents/Resources/maxima.sh" -b "integratemx1.max"
exit 0
