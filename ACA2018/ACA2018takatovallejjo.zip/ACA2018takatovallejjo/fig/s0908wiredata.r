# date time=2018/4/6 10:06:28

source('/Applications/KeTTeX.app/texlive/texmf-dist/scripts/ketcindy/ketlib/ketpiccurrent.r')
Ketinit()
cat(ThisVersion,'\n')
Fnametex='s0908wiredata.tex'
FnameR='s0908wiredata.r'
Fnameout='s0908wiredata.txt'
arccos=acos; arcsin=asin; arctan=atan

Setwindow(c(-4.26,4.44), c(-2.13,5.39))
TH=c(-1.5,-2.75);Assignadd('TH',TH)
FI=c(-3.82484,-3.25);Assignadd('FI',FI)
O=c(0,0);Assignadd('O',O)
Oz=c(8.702153,0);Assignadd('Oz',Oz)
X=c(-2.92572,-0.93292);Assignadd('X',X)
Xz=c(5.776433,0);Assignadd('Xz',Xz)
Y=c(2.72767,-1.00066);Assignadd('Y',Y)
Yz=c(11.429823,0);Assignadd('Yz',Yz)
Z=c(0,3.75877);Assignadd('Z',Z)
Zz=c(8.702153,4);Assignadd('Zz',Zz)
O3d=c(0,0,0);Assignadd('O3d',O3d)
Ofix=1;Assignadd('Ofix',Ofix)
X3d=c(4,0,0);Assignadd('X3d',X3d)
Xfix=1;Assignadd('Xfix',Xfix)
Y3d=c(0,4,0);Assignadd('Y3d',Y3d)
Yfix=1;Assignadd('Yfix',Yfix)
Z3d=c(0,0,4);Assignadd('Z3d',Z3d)
Zfix=1;Assignadd('Zfix',Zfix)
sgth=Listplot(c(c(-5,-2.75),c(4,-2.75)))
sgph=Listplot(c(c(-5,-3.25),c(4,-3.25)))
Setangle(70,47.0064)
ax3d=Xyzax3data("x=c(-5,5)","y=c(-5,5)","z=c(-5,5)")
ax2d=Projpara(ax3d)
Tmpout=ReadOutData("s0908wiredatasfbd1.txt")
Tmpout=ReadOutData("s0908wiredatasfbd1.txt")
Tmpout=ReadOutData("s0908wiredatacrvsf1.txt")
Tmpout=ReadOutData("s0908wiredatacrvsf1.txt")
Tmpout=ReadOutData("s0908wiredatawire1.txt")
Tmpout=ReadOutData("s0908wiredatawire1.txt")
PtL=list()
GrL=list()

# Windisp(GrL)

if(1==1){

Openfile('s0908wiredata.tex','1cm','Cdy=s0908wiredata.cdy')
Letter(c(-3.84,-1.22),"c","$x$")
Letter(c(3.59,-1.32),"c","$y$")
Letter(c(0,4.89),"c","$z$")
Drwline(sfbd2d1)
Dottedline(sfbdh2d1)
Drwline(crvsf2d1)
Dottedline(crvsfh2d1)
Drwline(wire2d1)
Dottedline(wireh2d1)
Closefile('0')

}

quit()
